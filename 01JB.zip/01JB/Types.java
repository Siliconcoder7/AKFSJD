class Types{
public static void main(String[] args){
char name='R';
int age=24;
long mob=8207574817L;
String course="java";
double fee=17.5;
String pan="jbkjbdc";

System.out.println("Name: " + name + ",\nAge: " + age + ", \nMobile: " + mob + ", \nCourse: " + course + ", \nFee: " + fee + ", \nPAN: " + pan);
}} 