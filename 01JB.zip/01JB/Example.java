class BankAccount{
	    String bankname ="SBI";
		String bankbranch="RANCHI";
		String ifsc="SBIN00RC";
		long Accnum=8545954425;
		String Acchname="RISHI";
		double balance=545987555;
}

class 
{
}