

  class Example1{
	int x;
	int y;
	{
		x=40;
	}
	Example1(){
		y=45;
	}
	Example1(int y){
		this.y=y;
	}
	Example1(String s){
		this.y=Integer.parseInt(s);
	}
}

public class Test1 {
public static void main(String []args) {
	Example1 E1=new Example1();
Example1 E2=new Example1(70);
Example1 E3=new Example1("30");

System.out.println(E1.x +" " +E1.y );
System.out.println(E2.x +" " +E2.y );
System.out.println(E3.x +"�"�+E3.y�);
}}