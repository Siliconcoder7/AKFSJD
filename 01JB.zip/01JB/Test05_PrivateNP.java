class Example {
	private static void m1() {
		System.out.println("m1");
	}

	static void m2() {
		System.out.println("m2");
	}

	static void m3() {1
		System.out.println("m3");
		m1();
	}

	public static void main(String[] args) {
		m1();		
		m2();		
		m3();		
	}
}

class Test05_PrivateNP {
	public static void main(String[] args) {
		//m1();  //CE: c f s method m1()	
		//m2();  //CE: c f s method m2()
		//m3();  //CE: c f s method m3()
		
		//Example.m1();  //CE:  m1() has private access in Example
		Example.m2();
		
		Example.m3();
	
	}
}