class BankAccount{
	static String Bankname;
	static String Branchname;
	static String IFSC;
	String bhname;
	long Bno;
	double salary;
	
	
	
}
 public class Bank{
	public static void main(String [] args){
		BankAccount.Bankname="SBI";
		BankAccount.Branchname="RANCHI";
		BankAccount.IFSC="SBI52452";
		
		
		BankAccount B1=new BankAccount();
		BankAccount B2=new BankAccount();
		
		B1.bhname="BK";
		B1.Bno=11;
		B1.salary=500056464;
		
		
		
		B2.bhname="hk";
		B2.Bno=12;
		B2.salary=5000;
		
		System.out.println("DETAILS OF B1");
		System.out.println("B1.BANKNAME:" +B1.Bankname);
		System.out.println("B1.BRANCH NAME:" +B1.Branchname);
		System.out.println("B1.IFSC:" +B1.IFSC);
		System.out.println("B1.bhname:" +B1.bhname);
		System.out.println("B1.Bnp:" +B1.Bno);
		System.out.println("B1.SALARY:" +B1.salary);
		
		
		System.out.println("DETAILS OF B2");
		System.out.println("B2.BANKNAME:" +B2.Bankname);
		System.out.println("B2.BRANCH NAME:" +B2.Branchname);
		System.out.println("B2.IFSC:" +B2.IFSC);
		System.out.println("B2.bhname:" +B2.bhname);
		System.out.println("B2.Bnp:" +B2.Bno);
		System.out.println("B2.SALARY:" +B2.salary);
	}}
		
		
		
		
		
			
	
	
	
