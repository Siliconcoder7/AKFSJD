class Student{
int sno;
String sname;
String course;
double fee;
}
public class College{
public static void main(String [] args){
Student s1=new Student();
Student s2=new Student();

s1.sno=101;
s1.sname="Rishi";
s1.course="Java Full Stack";
s1.fee=2000;

s2.sno=102;
s2.sname="HK";
s2.course="Java Full Stack";
s2.fee=2000;

System.out.println("s1 objects");
System.out.println("s1.sno\t :"+s1.sno);
System.out.println("s1.sname\t:"+s1.sname);
System.out.println("s1.course\t:" +s1.course);
System.out.println("s1.fee\t:"    +s1.fee);



System.out.println("s2 objects");
System.out.println("s2.sno\t:"   +s2.sno);
System.out.println("s2.sname\t:" +s2.sname);
System.out.println("s2.course\t:"+s2.course);
System.out.println("s2.fee\t:"   +s1.fee);
}}



