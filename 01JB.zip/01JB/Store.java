class Store{
public static void main(String[] args){
double [] a={10.2,11.2,12.3};

System.out.println("a:"+a);
}
}
