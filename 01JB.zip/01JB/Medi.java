class Medi{
public static void main(String[] args){
String [] a={hk,rk,pk,gk};

System.out.println("a:"+a);
}
}
