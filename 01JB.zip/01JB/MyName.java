class MyName{
public static void main(String[] args){
System.out.println("Rishi Kumar Gupta");
}}