class Room{
	private Double length;
	private Double breadth;
	
	public Room(Double length,double breadth){
		this.length=lenght;
		this.breadth=breadth;
	}
	public void setlength(double length){
		this.length=length;
		
		public void getlength(){
			return length;
		}
		public void Set breadth(){
		this.breadth=breadth;
		
		public void getbreadth(){
			return breadth;
		}
		public void find area(){
			system.out.println("area :" +length*breadth);
		}
		public void find parameter(){
			system.out.println("area of parameter :" +2(length*breadth));
		}
		public void display(){
			system.out.println("length :" +length);
			system.out.println("breadth :" breadth));
		
		}
		public Building{
			public static void main(String [] args){
				room r1=new room(50,20);
				system.out.println("display");
				r1.display();
				r1.find area();
				r1.find parameter();
			}}
				