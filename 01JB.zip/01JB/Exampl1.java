class Example{
long l1=10;
float f1=20.5f;
boolean bo=true;
char[] ca={'a','b','c'};
}
class Main{ 
public static void main(String[]args){
Example s1=new Example();
System.out.println(s1.l1);
System.out.println(s1.f1);
System.out.println(s1.bo);
System.out.println(s1.ca[0]);
}}